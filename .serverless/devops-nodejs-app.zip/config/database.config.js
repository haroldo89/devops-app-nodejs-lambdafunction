module.exports = {
    urlLocal: 'mongodb://localhost:27017/easy-notes',
    urlServer: 'mongodb+srv://admin:quevida890q12@cluster0.zl8gh.mongodb.net/easy-notes?retryWrites=true&w=majority',
    user: 'admin',
    pass: 'quevida890q12'
}